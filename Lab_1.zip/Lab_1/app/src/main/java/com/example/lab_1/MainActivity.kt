package com.example.lab_1

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.lab1_task3)

        var count=1
        var num= findViewById<TextView>(R.id.counter)
        var ltoast= findViewById<Button>(R.id.toast)
        var click= findViewById<Button>(R.id.Counter)

        click.setOnClickListener {
            num.setText(""+count++)
        }

        ltoast.setOnClickListener {
            //num.setText("hi")
            Toast.makeText(this,"Toast",Toast.LENGTH_LONG).show()
        }

    }
}